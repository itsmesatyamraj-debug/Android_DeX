# Android DEX — Android WebView Build

This project packages the supplied Android DEX website/documentation into a native Android APK shell.

## Important
The supplied ZIP does **not** contain the original Flutter/Dart desktop source, Kotlin companion APK source, Java JAR logic engine, or Windows/macOS/Linux runtime. It contains the public website/documentation and media assets. Therefore this Android build reproduces the supplied UI/documentation as an Android app; it does not magically provide the desktop ADB/scrcpy functionality described in the documentation.

## Build on GitHub
1. Upload this project to a GitHub repository.
2. Open **Actions**.
3. Run **Build Android APK**.
4. Download the `AndroidDEX-debug-apk` artifact.

The app uses Android WebView and keeps the supplied HTML/CSS/media files inside the APK.
